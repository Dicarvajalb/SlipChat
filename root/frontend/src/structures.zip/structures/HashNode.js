const { model } = require("../../../backend/src/models/users");

class HashNode{
  constructor(value, key){
    this.value = value;
    this.key = key;
    this.next = undefined;
  }

  

}

module.exports = HashNode

