const HashNode = require("./HashNode")

class HashTable{

  constructor(Capacity, p){
    this.capacity = Capacity
    this.table = new Array(Capacity)
    this.elements = 0
    this.p = p
    this.a = Math.floor(Math.random() * (p-1)) + 1
    this.b = Math.floor(Math.random() * (p-1)) + 1
    this.x = Math.floor(Math.random() * (p-1)) + 1
  }
  getIndex(k){
    var index = 0;
    if (typeof k === "string") {
      index = this.polyhash(k)
    }
    else if(typeof k === "number"){
      index = this.hashInt(k)
    }
    else{
      console.log("?????")
    }
    return index
  }

  insert(k, v){
    var index = this.getIndex(k)
    var alive = this.table[index]

    if(alive == undefined){
      this.table[index] = new HashNode(v,k)
      this.elements++
    }
    while(alive != undefined){
      if(alive.k === k){
        console.log(alive);
        alive.value = v
        break;
      }
      if(alive.next === undefined){
        alive.next = new HashNode(v,k);
        this.elements++
        break;
      }
      alive = alive.next;
    }
    console.log(index);
  }

  hashInt(k){
    return ((this.a*k + this.b)%this.p)%this.capacity;
  }

  polyhash(k){
    var polyValue = 0
    for(let i = k.length -1 ; i>=0 ; i--){
      polyValue = (polyValue*this.x + k.charCodeAt(i)) % this.p
    }
    
    return this.hashInt(polyValue);
  }
  
    
  

}

let hash = new HashTable(4, 552493)

hash.insert("Holap", 4);
hash.insert("Holapa", 3);
hash.insert("Holapr", 3);
hash.insert("Holapx", 3);
hash.insert("Holapa", 3)
console.log(hash.elements)
