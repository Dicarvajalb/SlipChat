const stack = require('./stack.js')

const chat = require('../data/chat.js')

let Stack = new stack(2);


console.log(chat.array)